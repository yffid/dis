import 'package:flutter/material.dart';
import 'kds_page.dart';

class KdsPageWrapper extends StatelessWidget {
  const KdsPageWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return const KdsScreen();
  }
}
