// NOTE: All product, order, and kitchen data is now received from the Cashier App via WebSocket
// Mock data has been removed. Real data flows through:
// - SocketService for WebSocket communication
// - DisplayProvider for state management
// - Real-time updates from Cashier App
